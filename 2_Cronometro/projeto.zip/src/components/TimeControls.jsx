function TimeControls({ timerOn, onStart, onStop }) {
  return (
    <div className="timer-controls">
        {!timerOn &&
            <button
                className="start"
                onClick={onStart}
            >Iniciar</button>
        }
        {timerOn &&
            <button
                className="stop"
                onClick={onStop}
            >Parar</button>
        }
        {timerOn &&
            <button
                className="mark"
            >Marcar</button>
        }
        <button
            className="clear"
        >Zerar</button>
    </div>
  )
}

export default TimeControls