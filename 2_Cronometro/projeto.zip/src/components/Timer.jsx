import LapList from "./LapList"
import TimeControls from "./TimeControls"
import TimerDisplay from "./TimerDisplay"

import './Timer.css'
import { useEffect, useState } from "react"

function Timer() {

  const [ms, setMs] = useState(0)
  const [timerOn, setTimerOn] = useState(false)
  const [laps, setLaps] = useState([])

  const formatTime = () => {
    const minutes = ('0' + Math.floor(ms / 60_000) % 60).slice(-2)
    const seconds = ('0' + Math.floor(ms / 1000) % 60).slice(-2)
    const centiseconds = ('0' + Math.floor(ms / 10) % 100).slice(-2)

    return `${minutes}:${seconds}:${centiseconds}`
  }

  const startTime = (interval) => {
    return setInterval(() => {
        setMs(prevMs => prevMs + 10)
    }, 10)
  }

  const stopTimer = (interval) => {
    clearInterval(interval)
    return interval
  }

  useEffect(() => {
    let interval = null

    if (timerOn) {
        interval = startTime(interval)
    } else {
        interval = stopTimer(interval)
    }

    return () => stopTimer(interval)
  }, [timerOn])

  return (
    <div className="timer-container">
        <TimerDisplay time={formatTime()} />
        <TimeControls
            onStart={() => setTimerOn(true)}
            onStop={() => setTimerOn(false)}
        />
        <LapList />
    </div>
  )
}

export default Timer